export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-6 text-center">
      <div className="text-5xl">🔍</div>
      <h1 className="mt-4 text-xl font-bold text-slate-800">
        صفحه پیدا نشد
      </h1>
      <p className="mt-2 text-sm text-slate-500">
        مسیری که دنبال آن بودید وجود ندارد.
      </p>
    </main>
  );
}
