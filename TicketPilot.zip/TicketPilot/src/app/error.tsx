"use client";

export default function Error({
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-6 text-center">
      <div className="text-5xl">⚠️</div>
      <h1 className="mt-4 text-xl font-bold text-slate-800">
        خطایی رخ داد
      </h1>
      <p className="mt-2 text-sm text-slate-500">
        متأسفانه مشکلی پیش آمد. لطفاً دوباره تلاش کنید.
      </p>
      <button
        onClick={reset}
        className="mt-6 rounded-lg bg-indigo-600 px-6 py-3 text-sm font-medium text-white active:bg-indigo-700"
      >
        تلاش مجدد
      </button>
    </main>
  );
}
