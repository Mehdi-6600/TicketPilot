export default function Loading() {
  return (
    <main className="flex min-h-screen items-center justify-center">
      <p className="text-sm text-slate-500">در حال بارگذاری...</p>
    </main>
  );
}
