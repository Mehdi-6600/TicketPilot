import { redirect } from "next/navigation";

// مسیر اصلی توسط middleware هدایت می‌شود؛ اینجا فقط fallback است.
export default function Home() {
  redirect("/dashboard");
}
