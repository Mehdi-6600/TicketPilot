import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import {
  startOfToday,
  startOfTomorrow,
  formatDateFa,
} from "@/lib/timezone";

export const metadata = { title: "داشبورد | TicketPilot" };

export default async function DashboardPage() {
  const user = await requireUser();

  const today = startOfToday();
  const tomorrow = startOfTomorrow();

  const [
    customersCount,
    todayActivities,
    pendingFollowUps,
    overdueFollowUps,
    openBookings,
    todaySales,
  ] = await Promise.all([
    db.customer.count(),
    db.activity.count({ where: { createdAt: { gte: today } } }),
    db.followUp.count({
      where: { status: "PENDING", dueDate: { lt: tomorrow } },
    }),
    db.followUp.count({
      where: { status: "PENDING", dueDate: { lt: today } },
    }),
    db.booking.count({
      where: { status: { notIn: ["SOLD", "CANCELLED"] } },
    }),
    db.booking.aggregate({
      _sum: { amount: true },
      where: { status: "SOLD", updatedAt: { gte: today } },
    }),
  ]);

  const saleAmount = todaySales._sum.amount ?? 0;

  const cards = [
    {
      icon: "🧑‍🤝‍🧑",
      label: "مشتریان",
      value: customersCount,
      tint: "bg-sky-50 text-sky-700",
    },
    {
      icon: "📞",
      label: "فعالیت‌های امروز",
      value: todayActivities,
      tint: "bg-indigo-50 text-indigo-700",
    },
    {
      icon: "🔔",
      label: "پیگیری‌های باز",
      value: pendingFollowUps,
      tint: "bg-amber-50 text-amber-700",
    },
    {
      icon: "🎫",
      label: "رزروهای باز",
      value: openBookings,
      tint: "bg-violet-50 text-violet-700",
    },
    {
      icon: "💰",
      label: "فروش امروز (تومان)",
      value: saleAmount.toLocaleString("fa-IR"),
      tint: "bg-emerald-50 text-emerald-700",
    },
  ];

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-gradient-to-l from-indigo-600 to-indigo-500 p-5 text-white shadow">
        <p className="text-sm opacity-80">
          {formatDateFa(today)}
        </p>
        <h1 className="mt-1 text-lg font-bold">
          سلام، {user.name ?? user.username} 👋
        </h1>
      </div>

      {overdueFollowUps > 0 && (
        <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
          🔴 شما {overdueFollowUps.toLocaleString("fa-IR")} پیگیری عقب‌افتاده
          دارید.
        </div>
      )}

      <div className="grid grid-cols-2 gap-3">
        {cards.map((card) => (
          <div
            key={card.label}
            className="rounded-2xl bg-white p-4 shadow-sm"
          >
            <div
              className={`inline-flex h-9 w-9 items-center justify-center rounded-xl text-lg ${card.tint}`}
            >
              {card.icon}
            </div>
            <p className="mt-3 text-2xl font-bold text-slate-800">
              {card.value}
            </p>
            <p className="mt-1 text-xs text-slate-500">{card.label}</p>
          </div>
        ))}
      </div>

      <p className="pt-2 text-center text-xs text-slate-400">
        فازهای بعدی (مشتریان، ثبت سریع فعالیت، پیگیری‌ها، گزارش روز) به‌زودی
        اضافه می‌شوند.
      </p>
    </div>
  );
}
