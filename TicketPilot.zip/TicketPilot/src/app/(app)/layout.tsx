import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { logout } from "./actions";

export default async function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await requireUser();

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col">
      <header className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3">
        <div className="flex items-center gap-2">
          <span className="text-xl">✈️</span>
          <span className="font-bold text-slate-800">TicketPilot</span>
        </div>
        <form action={logout}>
          <button
            type="submit"
            className="rounded-lg px-3 py-1.5 text-xs text-slate-500 active:bg-slate-100"
          >
            خروج ({user.name ?? user.username})
          </button>
        </form>
      </header>

      <main className="flex-1 px-4 py-4 pb-24">{children}</main>

      <nav className="fixed bottom-0 left-0 right-0 z-10 border-t border-slate-200 bg-white">
        <div className="mx-auto grid max-w-md grid-cols-5 text-center text-[11px]">
          <Link
            href="/dashboard"
            className="flex flex-col items-center gap-1 py-2.5 text-indigo-600"
          >
            <span className="text-lg">🏠</span>
            داشبورد
          </Link>
          <span className="flex flex-col items-center gap-1 py-2.5 text-slate-300">
            <span className="text-lg">🧑‍🤝‍🧑</span>
            مشتریان
          </span>
          <span className="flex flex-col items-center gap-1 py-2.5 text-slate-300">
            <span className="text-lg">🔄</span>
            پیگیری‌ها
          </span>
          <span className="flex flex-col items-center gap-1 py-2.5 text-slate-300">
            <span className="text-lg">✈️</span>
            مسافران
          </span>
          <span className="flex flex-col items-center gap-1 py-2.5 text-slate-300">
            <span className="text-lg">📝</span>
            گزارش
          </span>
        </div>
      </nav>
    </div>
  );
}
