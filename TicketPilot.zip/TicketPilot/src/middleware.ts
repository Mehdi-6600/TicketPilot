import { NextRequest, NextResponse } from "next/server";

// لایه اول محافظت (قانون ۷۵) — بررسی وجود کوکی.
// اعتبارسنجی واقعی در requireUser داخل سرور انجام می‌شود.
// نکته: middleware روی Edge اجرا می‌شود و نمی‌تواند node:crypto را import کند؛
// برای همین فقط وجود کوکی بررسی می‌شود، نه امضای آن.
// نام کوکی باید با SESSION_COOKIE در src/lib/session.ts یکسان باشد.

const SESSION_COOKIE = "tp_session";

const PROTECTED_PREFIXES = [
  "/dashboard",
  "/customers",
  "/followups",
  "/travelers",
  "/bookings",
  "/report",
  "/settings",
  "/activity",
];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const hasSession = req.cookies.has(SESSION_COOKIE);

  if (pathname === "/") {
    const url = req.nextUrl.clone();
    url.pathname = hasSession ? "/dashboard" : "/login";
    return NextResponse.redirect(url);
  }

  const isProtected = PROTECTED_PREFIXES.some(
    (p) => pathname === p || pathname.startsWith(p + "/")
  );

  if (isProtected && !hasSession) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.search = "";
    return NextResponse.redirect(url);
  }

  if (pathname === "/login" && hasSession) {
    const url = req.nextUrl.clone();
    url.pathname = "/dashboard";
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
};
