import { cache } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "./db";
import { SESSION_COOKIE, verifySessionToken } from "./session";

// قانون ۷۵: اعتبارسنجی واقعی داخل سرور است — middleware فقط لایه اول است.
// هر صفحه و هر Server Action خصوصی باید requireUser() را صدا بزند.

export const getCurrentUser = cache(async () => {
  const token = cookies().get(SESSION_COOKIE)?.value;
  const payload = verifySessionToken(token);
  if (!payload) return null;

  const user = await db.user.findUnique({
    where: { id: payload.uid },
    select: { id: true, username: true, name: true },
  });
  return user;
});

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) {
    redirect("/login");
  }
  return user;
}
