// وضعیت‌ها و برچسب‌های فارسی — مرکزی و قابل تغییر (قانون ۵۸)

export const ACTIVITY_TYPES = [
  { value: "CALL", label: "تماس", icon: "📞" },
  { value: "REPLY", label: "پاسخ به مشتری", icon: "💬" },
  { value: "INQUIRY", label: "استعلام", icon: "🔎" },
  { value: "PRICE", label: "اعلام قیمت", icon: "💰" },
  { value: "FOLLOW_UP", label: "پیگیری", icon: "🔄" },
  { value: "BOOKING", label: "رزرو", icon: "🎫" },
  { value: "SALE", label: "فروش", icon: "✅" },
  { value: "CANCELLATION", label: "کنسلی", icon: "❌" },
  { value: "NOTE", label: "یادداشت", icon: "📝" },
] as const;

export type ActivityTypeValue = (typeof ACTIVITY_TYPES)[number]["value"];

export const BOOKING_STATUS_LABELS: Record<string, string> = {
  INQUIRY: "استعلام",
  PRICE_ANNOUNCED: "قیمت اعلام شد",
  WAITING_DECISION: "منتظر تصمیم",
  RESERVED: "رزرو",
  TICKET_ISSUED: "بلیط صادر شد",
  SOLD: "فروش",
  CANCELLED: "کنسلی",
};

export const TRAVEL_STATUS_LABELS: Record<string, string> = {
  RESERVED: "رزرو شده",
  TICKET_ISSUED: "بلیط صادر شده",
  IN_TRAVEL: "در سفر",
  RETURNED: "برگشت",
  COMPLETED: "پایان",
};
