// ─────────────────────────────────────────────────────────────
// مرکز مدیریت زمان برنامه — قانون ۲۶ Master Prompt
// «امروز» و «فردا» فقط از همین ماژول محاسبه می‌شوند.
// هرگز timezone را در فایل‌های دیگر hard-code نکن.
// ─────────────────────────────────────────────────────────────

export const APP_TIMEZONE = "Asia/Tehran";

type TzParts = {
  year: string;
  month: string;
  day: string;
  hour: string;
  minute: string;
  second: string;
};

function getTzParts(date: Date): TzParts {
  const dtf = new Intl.DateTimeFormat("en-US", {
    timeZone: APP_TIMEZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  });
  const parts: Record<string, string> = {};
  for (const p of dtf.formatToParts(date)) {
    if (p.type !== "literal") parts[p.type] = p.value;
  }
  return parts as unknown as TzParts;
}

function tzOffsetMinutes(date: Date): number {
  const p = getTzParts(date);
  const asUTC = Date.UTC(
    Number(p.year),
    Number(p.month) - 1,
    Number(p.day),
    Number(p.hour),
    Number(p.minute),
    Number(p.second)
  );
  return Math.round((asUTC - date.getTime()) / 60000);
}

/** ابتدای امروز (نیمه‌شبه به وقت تهران) به‌صورت Date — برای مقایسه با فیلدهای DateTime دیتابیس */
export function startOfToday(): Date {
  const now = new Date();
  const shifted = new Date(now.getTime() + tzOffsetMinutes(now) * 60000);
  return new Date(
    Date.UTC(shifted.getUTCFullYear(), shifted.getUTCMonth(), shifted.getUTCDate())
  );
}

/** ابتدای فردا به وقت تهران */
export function startOfTomorrow(): Date {
  return new Date(startOfToday().getTime() + 24 * 60 * 60 * 1000);
}

/** دیروز به وقت تهران */
export function startOfYesterday(): Date {
  return new Date(startOfToday().getTime() - 24 * 60 * 60 * 1000);
}

/** نمایش تاریخ شمسی کامل، مثلاً: دوشنبه ۷ مهر ۱۴۰۵ */
export function formatDateFa(date: Date): string {
  return new Intl.DateTimeFormat("fa-IR", {
    timeZone: APP_TIMEZONE,
    dateStyle: "full",
  }).format(date);
}

/** نمایش تاریخ و ساعت شمسی کوتاه */
export function formatDateTimeFa(date: Date): string {
  return new Intl.DateTimeFormat("fa-IR", {
    timeZone: APP_TIMEZONE,
    dateStyle: "short",
    timeStyle: "short",
  }).format(date);
}

/** نمایش ساعت */
export function formatTimeFa(date: Date): string {
  return new Intl.DateTimeFormat("fa-IR", {
    timeZone: APP_TIMEZONE,
    timeStyle: "short",
  }).format(date);
}
