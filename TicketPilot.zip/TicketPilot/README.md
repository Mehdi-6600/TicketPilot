# TicketPilot ✈️

دستیار کاری شخصی برای کارمند فروش و رزرو بلیط هواپیما.
Mobile First — فارسی — RTL — رایگان ($0)

## استک

Next.js 14 (App Router) · React 18 · TypeScript · Prisma 5 · PostgreSQL (Neon) · Tailwind CSS · bcryptjs · Zod

## راه‌اندازی (Codespaces)

```bash
# ۱) نصب وابستگی‌ها
npm install

# ۲) ساخت فایل محیطی
cp .env.example .env.local
# سپس مقدارهای داخلش را پر کن (DATABASE_URL نئون، SESSION_SECRET، ADMIN_USERNAME، ADMIN_PASSWORD)

# ۳) ساخت جداول دیتابیس
npx prisma migrate dev --name init

# ۴) ساخت کاربر اول
npm run db:seed

# ۵) اجرا
npm run dev
```

سپس در مرورگر: `http://localhost:3000`

## ساخت دیتابیس Neon (رایگان)

1. برو به https://neon.tech و با گیت‌هاب وارد شو
2. New Project → اسم TicketPilot → Create
3. از بخش Connection Details گزینه **Pooler** را فعال کن و رشته اتصال را کپی کن
4. آن را در `DATABASE_URL` داخل `.env.local` بگذار

## دیپلوی روی Vercel

1. برو به https://vercel.com و با گیت‌هاب وارد شو
2. Add New → Project → ریپوی TicketPilot را Import کن
3. در بخش Environment Variables این سه را اضافه کن:
   - `DATABASE_URL` (همان رشته Pooler نئون)
   - `SESSION_SECRET` (یک رشته تصادفی طولانی)
   - `ADMIN_USERNAME` و `ADMIN_PASSWORD` (فقط برای seed)
4. Deploy
5. بعد از اولین deploy برای ساخت کاربر: locally یا via Vercel CLI اجرا کن:
   ```bash
   npx prisma migrate deploy
   npm run db:seed
   ```

## امنیت

- هرگز `.env.local` را کامیت نکن (در .gitignore هست)
- هرگز DATABASE_URL واقعی یا SESSION_SECRET را در چت یا کد نگذار
- فقط نام متغیرهای محیطی را نشان بده

## ساختار

- `prisma/schema.prisma` — مدل‌های User, Customer, Travel, Booking, FollowUp, Activity, DailyReport
- `src/lib/session.ts` — کوکی امضاشده (HMAC-SHA256) با SESSION_SECRET
- `src/lib/auth.ts` — getCurrentUser و requireUser (برای هر صفحه/اکشن خصوصی)
- `src/middleware.ts` — لایه اول محافظت (بررسی وجود کوکی)
- `src/app/(app)/` — صفحات داخلی محافظت‌شده
- `src/app/login/` — صفحه ورود + Server Action

## Timezone

منطقه زمانی مرکزی برنامه: **Asia/Tehran** (در `src/lib/timezone.ts`)
تمام مفاهیم امروز/فردا/گزارش روز از همین ماژول استفاده می‌کنند.
