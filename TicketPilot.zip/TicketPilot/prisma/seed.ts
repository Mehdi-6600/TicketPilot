import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const username = process.env.ADMIN_USERNAME;
  const password = process.env.ADMIN_PASSWORD;

  if (!username || !password) {
    throw new Error(
      "ADMIN_USERNAME و ADMIN_PASSWORD باید در فایل .env.local تعریف شوند."
    );
  }

  const existing = await prisma.user.findUnique({ where: { username } });
  if (existing) {
    console.log("کاربر از قبل وجود دارد. seed انجام نشد.");
    return;
  }

  const passwordHash = await bcrypt.hash(password, 10);
  await prisma.user.create({
    data: { username, passwordHash, name: "کارمند" },
  });

  console.log("کاربر با موفقیت ساخته شد.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
